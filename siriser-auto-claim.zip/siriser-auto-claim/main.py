import argparse
import asyncio
import json
import logging
import logging.handlers
import os
import signal
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from claimbot.browser import BrowserSession, pick_selector, prompt
from claimbot.core import Engine, NeedsLogin, NeedsReview, RateLimited, SiteChanged, Store, atomic_json, canonical_url, flush_outbox
from claimbot.push import WxPusher, load_env

ROOT = Path(__file__).resolve().parent


def load_config(root):
    path = root / "config.json"
    if not path.exists():
        raise ValueError("先复制 config.example.json 为 config.json")
    config = json.loads(path.read_text(encoding="utf-8-sig"))
    canonical_url(config["market_url"])
    if config["poll_seconds"] != 60:
        raise ValueError("此版本的检查周期固定为 60 秒")
    if config["list_mode"] not in ("single", "pagination", "scroll"):
        raise ValueError("list_mode 必须为 single / pagination / scroll")
    for field, low, high in [("navigation_timeout_ms", 1000, 60000), ("confirmation_timeout_ms", 1000, 60000),
                             ("page_delay_seconds", 0.2, 10), ("max_pages", 1, 100), ("max_scrolls", 1, 100)]:
        if not isinstance(config[field], (int, float)) or not low <= config[field] <= high:
            raise ValueError("配置范围不正确：" + field)
    return config


def require_calibrated(config, dry_run=False):
    required = ("market_ready", "card", "claim") if dry_run else ("market_ready", "card", "claim", "confirmed")
    ready = config.get("calibrated") or (dry_run and config.get("navigation_calibrated"))
    if not ready or any(not config["selectors"].get(k) for k in required):
        raise ValueError("首次运行前需要执行 setup 完成真实页面按钮校准")


@contextmanager
def profile_lock(root):
    folder = root / "data"
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(folder, 0o700)
    f = (folder / "process.lock").open("a+b")
    try:
        if sys.platform == "win32":
            import msvcrt
            f.seek(0)
            f.write(b"0")
            f.flush()
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise ValueError("已有进程占用浏览器；先停止后台服务，再登录或校准") from None
    try:
        yield
    finally:
        f.close()


def logging_setup(root):
    folder = root / "logs"
    folder.mkdir(exist_ok=True, mode=0o700)
    logger = logging.getLogger("siriser")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        for handler in [logging.StreamHandler(), logging.handlers.RotatingFileHandler(
            folder / "worker.log", maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8")]:
            handler.setFormatter(formatter)
            logger.addHandler(handler)
    return logger


async def authenticate(browser):
    await browser.page.goto(browser.config["market_url"], wait_until="domcontentloaded")
    print("请在浏览器中完成短信登录和人工验证，进入项目中心后回终端按 Enter。", flush=True)
    await prompt("")
    candidates = [p for p in browser.context.pages if not p.is_closed() and
                  p.url.startswith("https://www.siriser.com/siriser/market")]
    if not candidates:
        raise NeedsLogin("未找到已登录的项目中心页面")
    browser.page = candidates[-1]
    browser.http_problem = None
    await browser.check(browser.page)
    if not await browser.visible(browser.page, browser.s["market_ready"]):
        raise NeedsLogin("尚未进入项目中心；如页面名称不同，先修改 market_ready")
    await browser.save_auth()
    # Closing the persistent context commits cookies, local storage and IndexedDB.
    print("登录验证通过，登录状态会保存到 data/browser。")


async def setup(root, config):
    async with BrowserSession(root, config, headed=True) as browser:
        await authenticate(browser)
        config["calibrated"] = False
        config["navigation_calibrated"] = False
        atomic_json(root / "config.json", config)
        s = config["selectors"]
        s["card"] = await pick_selector(browser.page,
            "请在浏览器点击一张项目卡片的标题；随后选择能匹配全部项目卡片的父级。", repeated=True)
        s["title"] = await prompt("卡片内标题选择器（可留空，使用卡片第一行）：")
        s["detail_link"] = await prompt("卡片内详情链接选择器（默认 a[href]，没有链接输入 none）：") or "a[href]"
        if s["detail_link"] == "none":
            s["detail_link"] = ""
        s["id_attribute"] = await prompt("卡片项目ID属性（例如 data-id；有唯一详情链接可留空）：")
        s["entry"] = await prompt('卡片内进入详情的控件选择器 [text="去领取"]（不是详情页的领取按钮）：') or 'text="去领取"'
        config["list_mode"] = await prompt("列表类型 single / pagination / scroll [single]：") or "single"
        if config["list_mode"] == "pagination":
            s["next_page"] = await pick_selector(browser.page, "请选择下一页按钮（不会真正翻页）。")
        projects = await browser.list_projects()
        if not projects:
            raise SiteChanged("没有识别到项目；请有项目时再校准")
        for index, p in enumerate(projects, 1):
            print(index, p.key, p.title)
        if await prompt(f"共识别 {len(projects)} 个项目，列表是否正确？输入 yes：") != "yes":
            raise SiteChanged("用户未确认列表")
        selected = await prompt("选择一个项目编号，余量为0也可用于只读校准 [1]：") or "1"
        if not selected.isdigit() or not 1 <= int(selected) <= len(projects):
            raise ValueError("项目编号超出范围")
        s["detail_ready"] = ""
        await browser.open_project(projects[int(selected) - 1])
        value = await prompt('详情页实际领取控件选择器 [text="领取回答"]；输入 pick 可视化选择：')
        s["claim"] = await pick_selector(browser.detail, "请选择实际领取按钮（此次选择不会执行领取）。") if value == "pick" else (value or 'text="领取回答"')
        control = browser.detail.locator(s["claim"])
        if await control.count() != 1 or not await control.is_visible():
            raise SiteChanged("详情页领取控件未匹配或不唯一；请调整选择器")
        s["detail_ready"] = s["claim"]
        config["navigation_calibrated"] = True
        s["confirmed"] = s["success"] = ""
        atomic_json(root / "config.json", config)
        if await prompt("现在是否能核实实际成功状态？yes 继续；回车先保存只读配置：") != "yes":
            print("导航及第二步按钮配置已保存，可以 run --once --dry-run。未配置成功判定，实际自动领取仍禁用。")
            return
        print("请打开本人已领取的项目/任务，或在确实需要时人工领取一次。不必为了截图领取。")
        await prompt("看到表示已领取的稳定状态后按 Enter：")
        active = browser.context.pages[-1]
        await browser.check(active)
        s["confirmed"] = await pick_selector(active, "请选择表示本项目已经领取的稳定标记或按钮。")
        s["success"] = await prompt("领取成功提示选择器（可选；可留空）：")
        s["confirm_dialog"] = await prompt("普通二次确认按钮选择器（可留空；不要配置协议或考核按钮）：")
        s["challenge"] = await prompt("人工验证区域选择器（可选；可留空）：")
        config["calibrated"] = True
        require_calibrated(config)
        atomic_json(root / "config.json", config)
        print("真实页面校准已保存。先执行 run --once --dry-run，再启动服务。")


def pause(root, store, kind, description, logger):
    path = root / "data" / "PAUSED.json"
    if path.exists():
        return
    event_id = str(time.time_ns())
    atomic_json(path, {"kind": kind, "reason": description, "time": time.time(), "event_id": event_id})
    store.enqueue("pause:" + event_id, "自动领取已暂停", description)
    logger.warning("PAUSED kind=%s reason=%s", kind, description)


async def worker(root, config, notifier, once=False, dry_run=False):
    require_calibrated(config, dry_run=dry_run)
    if config["notifications_required"] and not notifier.configured and not dry_run:
        raise ValueError("先填写 .env 的 WxPusher 凭证并执行 test-push")
    logger = logging_setup(root)
    store = Store(root / "data" / "claims.sqlite3")
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            asyncio.get_running_loop().add_signal_handler(sig, stop.set)
        except NotImplementedError:
            signal.signal(sig, lambda *_: stop.set())
    paused = root / "data" / "PAUSED.json"
    if store.recover():
        pause(root, store, "uncertain", "上次领取结果不明确，请检查 status 并人工核对项目后 resolve。", logger)
    try:
        async with BrowserSession(root, config) as browser:
            engine = Engine(store, browser, logger)
            failures = 0
            while not stop.is_set():
                started = time.monotonic()
                if not paused.exists():
                    try:
                        await engine.cycle(dry_run=dry_run)
                        await browser.save_auth()
                        failures = 0
                        atomic_json(root / "data" / "last-check.json", {"time": time.time(), "ok": True})
                    except NeedsLogin:
                        pause(root, store, "login", "登录已失效。停止服务后重新短信登录，再 resume。", logger)
                    except RateLimited:
                        pause(root, store, "rate_limit", "平台已限流。检查后手动 resume；不会循环重试。", logger)
                    except (NeedsReview, SiteChanged) as error:
                        kind = "uncertain" if store.unresolved() else "verification"
                        pause(root, store, kind, str(error), logger)
                    except Exception:
                        failures += 1
                        logger.warning("SCAN_ERROR count=%d; browser details intentionally omitted", failures)
                        if store.unresolved():
                            pause(root, store, "uncertain", "点击领取后发生异常，结果未确认；请人工核对。", logger)
                        elif failures >= 3:
                            pause(root, store, "error", "连续三次页面检查失败，请检查网络和页面配置。", logger)
                if not dry_run:
                    await flush_outbox(store, notifier, logger, stop)
                if once:
                    return 2 if paused.exists() else 0
                # One round at a time. Missed minute ticks are skipped, never accumulated.
                elapsed = time.monotonic() - started
                wait = max(1, 60 - elapsed) if elapsed < 60 else 60 - (elapsed % 60)
                try:
                    await asyncio.wait_for(stop.wait(), timeout=wait)
                except asyncio.TimeoutError:
                    pass
    except Exception:
        pause(root, store, "browser", "浏览器启动或运行失败，请检查服务器依赖及浏览器进程。", logger)
        if not dry_run:
            await flush_outbox(store, notifier, logger, stop)
        return 1
    finally:
        store.close()
    return 0


async def dispatch(args, root, config, notifier):
    if args.command == "test-push":
        await asyncio.to_thread(notifier.send, "晓天领取脚本测试", "WxPusher 接口测试消息：这不是项目领取通知。")
        print("WxPusher 已接受测试消息，请在手机确认收到。")
        return 0
    if args.command == "run":
        return await worker(root, config, notifier, args.once, args.dry_run)
    if args.command == "setup":
        await setup(root, config)
        return 0
    if args.command in ("login", "inspect"):
        async with BrowserSession(root, config, headed=True) as browser:
            await authenticate(browser)
            if args.command == "inspect":
                atomic_json(root / "data" / "page-inspection.json", await browser.diagnostics())
                await browser.page.screenshot(path=str(root / "data" / "project-center.png"))
                print("页面诊断已保存在 data/page-inspection.json 和 project-center.png。")
        return 0
    store = Store(root / "data" / "claims.sqlite3")
    try:
        if args.command == "status":
            status = store.status()
            path = root / "data" / "PAUSED.json"
            status["paused"] = json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
            print(json.dumps(status, ensure_ascii=False, indent=2))
        elif args.command == "resume":
            require_calibrated(config)
            if store.unresolved():
                raise ValueError("存在未确认的领取；先逐条执行 resolve")
            (root / "data" / "PAUSED.json").unlink(missing_ok=True)
            print("暂停标记已清除，下次检查会继续。")
        elif args.command == "resolve":
            if not args.checked:
                raise ValueError("必须本人核对平台状态后使用 --checked")
            store.resolve(args.key, args.result)
            print("已记录人工核对结果。再执行 resume 恢复。")
    finally:
        store.close()
    return 0


def main():
    parser = argparse.ArgumentParser(description="Siriser 60-second project claiming worker")
    parser.add_argument("--root", type=Path, default=ROOT)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("login", "setup", "inspect", "test-push", "status", "resume"):
        sub.add_parser(name)
    run = sub.add_parser("run")
    run.add_argument("--once", action="store_true")
    run.add_argument("--dry-run", action="store_true")
    resolve = sub.add_parser("resolve")
    resolve.add_argument("key")
    resolve.add_argument("--result", choices=["claimed", "not-claimed"], required=True)
    resolve.add_argument("--checked", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    os.umask(0o077)
    try:
        config = load_config(root)
        notifier = WxPusher(load_env(root / ".env"))
        if args.command in ("run", "login", "setup", "inspect"):
            with profile_lock(root):
                return asyncio.run(dispatch(args, root, config, notifier))
        return asyncio.run(dispatch(args, root, config, notifier))
    except KeyboardInterrupt:
        return 130
    except (ValueError, NeedsLogin, SiteChanged) as error:
        print(str(error), file=sys.stderr)
        return 2
    except Exception:
        print("命令失败。请检查安装环境、浏览器和配置；不输出可能含令牌的底层错误。", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

