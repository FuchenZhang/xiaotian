import json
import tempfile
import unittest
from pathlib import Path

from main import load_config, profile_lock, require_calibrated


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = json.loads((Path(__file__).resolve().parents[1] / "config.example.json").read_text(encoding="utf-8"))

    def tearDown(self):
        self.temp.cleanup()

    def test_template_cannot_claim_without_calibration(self):
        with self.assertRaises(ValueError):
            require_calibrated(self.config)

    def test_interval_is_exactly_one_minute(self):
        self.config["poll_seconds"] = 1
        (self.root / "config.json").write_text(json.dumps(self.config), encoding="utf-8")
        with self.assertRaises(ValueError):
            load_config(self.root)

    def test_navigation_only_calibration_allows_read_only_not_real_claims(self):
        self.config["navigation_calibrated"] = True
        self.config["selectors"]["card"] = ".card"
        require_calibrated(self.config, dry_run=True)
        with self.assertRaises(ValueError):
            require_calibrated(self.config)

    def test_concurrent_browser_process_is_rejected(self):
        with profile_lock(self.root):
            with self.assertRaises(ValueError):
                with profile_lock(self.root):
                    self.fail("Second browser process acquired the same profile")
        with profile_lock(self.root):
            pass
