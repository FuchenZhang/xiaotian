import json
import logging
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from claimbot.core import Store, atomic_json
from main import worker


class Notifier:
    configured = True

    def __init__(self):
        self.messages = []

    def send(self, title, content, url=""):
        self.messages.append((title, content, url))


class IdleBrowser:
    scans = 0

    def __init__(self, *args):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    async def list_projects(self):
        self.scans += 1
        return []

    async def save_auth(self):
        pass


class BrokenBrowser(IdleBrowser):
    async def __aenter__(self):
        raise RuntimeError("Fixture browser startup failure")


class WorkerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = json.loads((Path(__file__).resolve().parents[1] / "config.example.json").read_text(encoding="utf-8"))
        self.config["calibrated"] = True
        self.config["selectors"].update(card=".card", claim=".claim", confirmed=".confirmed")
        self.notifier = Notifier()

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def test_paused_worker_does_not_poll_site_but_sends_queued_notifications(self):
        atomic_json(self.root / "data" / "PAUSED.json", {"kind": "login"})
        store = Store(self.root / "data" / "claims.sqlite3")
        store.enqueue("pause:test", "Paused", "Login expired")
        store.close()
        with patch("main.BrowserSession", IdleBrowser), patch("main.logging_setup", return_value=logging.getLogger("worker-tests")):
            code = await worker(self.root, self.config, self.notifier, once=True)
        self.assertEqual(code, 2)
        self.assertEqual(IdleBrowser.scans, 0)
        self.assertEqual(len(self.notifier.messages), 1)

    async def test_browser_start_failure_pauses_and_alerts(self):
        with patch("main.BrowserSession", BrokenBrowser), patch("main.logging_setup", return_value=logging.getLogger("worker-tests")):
            code = await worker(self.root, self.config, self.notifier, once=True)
        self.assertEqual(code, 1)
        status = json.loads((self.root / "data" / "PAUSED.json").read_text(encoding="utf-8"))
        self.assertEqual(status["kind"], "browser")
        self.assertEqual(len(self.notifier.messages), 1)
