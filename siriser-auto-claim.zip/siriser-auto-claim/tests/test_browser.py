import importlib.util
import json
import logging
import tempfile
import unittest
from contextlib import asynccontextmanager
from pathlib import Path
from unittest.mock import AsyncMock, patch
from urllib.parse import urlsplit

from claimbot.browser import BrowserSession
from claimbot.core import Engine, NeedsLogin, NeedsReview, SiteChanged, Store

AVAILABLE = importlib.util.find_spec("playwright") is not None
ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(AVAILABLE, "Playwright not installed; run requirements installation for browser tests")
class BrowserTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "data").mkdir()
        self.config = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        self.config["calibrated"] = True
        self.config["page_delay_seconds"] = 0.2
        self.config["confirmation_timeout_ms"] = 1000
        self.config["navigation_timeout_ms"] = 2000
        self.config["selectors"].update(market_ready="#ready", card=".project", title="h2", claim="#claim", confirmed="#claimed")
        self.store = Store(self.root / "data" / "claims.sqlite3")
        self.fixture = "success"
        self.hits = []
        self.list_page = 0
        self.session = BrowserSession(self.root, self.config)
        self.browser = await self.session.__aenter__()
        await self.browser.context.route("**/*", self.route)

    async def route(self, route):
        url = route.request.url
        self.hits.append(url)
        path = urlsplit(url).path
        if urlsplit(url).hostname != "www.siriser.com":
            await route.fulfill(status=200, content_type="text/html; charset=utf-8", body="<p>SMS login</p>")
            return
        if path == "/siriser/market":
            if self.fixture == "login":
                body = '<script>location.href="https://mozi-login.alibaba-inc.com/ssoLogin.htm"</script>'
            else:
                items = (1, 2)
                if self.fixture == "pagination":
                    items = (1, 2) if self.list_page == 0 else (3, 4)
                    self.list_page += 1
                body = '<h1 id="ready">项目中心</h1>' + ''.join(
                    f'<article class="project"><h2>Project {i}</h2><a href="/project/{i}">查看详情</a></article>' for i in items)
                if self.fixture in ("two-step", "two-step-zero", "two-step-no-success"):
                    body = '<h1 id="ready">项目中心</h1>' + ''.join(
                        f'''<article class="project" data-id="{i}" onclick="location.href='/wrong'">
                        <h2>Project {i}</h2><button onclick="event.stopPropagation();location.href='/siriser/market/detail?id={i}'">去领取</button></article>'''
                        for i in items)
                if self.fixture == "pagination":
                    disabled_next = "disabled" if self.list_page > 1 else ""
                    body += f'<button id="next" {disabled_next} onclick="location.reload()">下一页</button>'
            await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=body)
            return
        action = "document.querySelector('#claimed').hidden=false;this.disabled=true"
        if self.fixture in ("timeout", "two-step-no-success"):
            action = "this.disabled=true"
        disabled = "disabled" if self.fixture in ("disabled", "two-step-zero") else ""
        body = f'<h1>Project detail</h1><button id="claim" {disabled} onclick="{action}">领取回答</button><p id="claimed" hidden>已领取</p>'
        if self.fixture.startswith("two-step"):
            body += '<p>回答流程：已领取/余量</p><span>923/0</span>'
        if self.fixture == "delayed-detail":
            body = f'''<h1>Project detail</h1><script>setTimeout(() => {{
                document.body.insertAdjacentHTML('beforeend', {json.dumps(body)})
            }}, 600)</script>'''
        if self.fixture == "ambiguous":
            body += '<button id="claim">领取项目</button>'
        if self.fixture == "disabled-child":
            body = '<button disabled><span id="claim">领取项目</span></button><p id="claimed" hidden>已领取</p>'
        if self.fixture == "existing":
            body = '<p id="claimed">已领取</p>'
        if self.fixture == "limited":
            await route.fulfill(status=429, content_type="text/html; charset=utf-8", body="Too many requests")
            return
        await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=body)

    async def asyncTearDown(self):
        await self.session.__aexit__()
        self.store.close()
        self.temp.cleanup()

    async def test_two_actual_browser_clicks_confirmed_and_not_repeated(self):
        engine = Engine(self.store, self.browser, logging.getLogger("browser-tests"))
        await engine.cycle()
        self.assertEqual(len(self.store.pending()), 2)
        self.assertTrue(all(p["state"] == "confirmed" for p in self.store.status()["claims"]))
        await engine.cycle()
        self.assertEqual(len(self.store.pending()), 2)
        await self.browser.page.screenshot(path=str(self.root / "browser-pass.png"))

    async def test_no_confirmation_pauses_after_one_attempt(self):
        self.fixture = "timeout"
        with self.assertRaises(NeedsReview):
            await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(len(self.store.unresolved()), 1)
        self.assertEqual(self.store.pending(), [])

    async def test_disabled_button_no_attempt(self):
        self.fixture = "disabled"
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(self.store.status()["claims"], [])

    async def test_ambiguous_button_stops_without_click(self):
        self.fixture = "ambiguous"
        with self.assertRaises(SiteChanged):
            await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(self.store.status()["claims"], [])

    async def test_login_redirect_detected(self):
        self.fixture = "login"
        with self.assertRaises(NeedsLogin):
            await self.browser.list_projects()

    async def test_disabled_parent_of_calibrated_text_is_not_claimable(self):
        self.fixture = "disabled-child"
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(self.store.status()["claims"], [])

    async def test_pagination_claims_every_page(self):
        self.fixture = "pagination"
        self.config["list_mode"] = "pagination"
        self.config["selectors"]["next_page"] = "#next"
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(len(self.store.pending()), 4)

    async def test_rate_limit_stops_before_click(self):
        from claimbot.core import RateLimited
        self.fixture = "limited"
        with self.assertRaises(RateLimited):
            await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(self.store.status()["claims"], [])

    def configure_two_step(self, fixture):
        self.fixture = fixture
        self.config["selectors"].update(detail_link="", id_attribute="data-id",
            entry='text="去领取"', claim='text="领取回答"', detail_ready='text="领取回答"')

    async def test_entry_is_navigation_then_actual_second_stage_claim(self):
        self.configure_two_step("two-step")
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(len(self.store.pending()), 2)
        self.assertFalse(any(urlsplit(url).path == "/wrong" for url in self.hits))
        self.assertTrue(any(urlsplit(url).path == "/siriser/market/detail" for url in self.hits))

    async def test_zero_quota_disabled_second_button_is_not_a_success(self):
        self.configure_two_step("two-step-zero")
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(self.store.status()["claims"], [])
        self.assertEqual(self.store.pending(), [])

    async def test_second_click_and_global_counts_do_not_prove_success(self):
        self.configure_two_step("two-step-no-success")
        with self.assertRaises(NeedsReview):
            await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(len(self.store.unresolved()), 1)
        self.assertEqual(self.store.pending(), [])

    async def test_waits_for_second_stage_button_to_load(self):
        self.fixture = "delayed-detail"
        self.config["selectors"]["detail_ready"] = "#claim"
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(len(self.store.pending()), 2)

    async def test_existing_success_marker_also_makes_detail_ready(self):
        self.fixture = "existing"
        self.config["selectors"]["detail_ready"] = "#claim"
        await Engine(self.store, self.browser, logging.getLogger("browser-tests")).cycle()
        self.assertEqual(self.store.pending(), [])
        self.assertTrue(all(p["state"] == "existing" for p in self.store.status()["claims"]))

    async def test_setup_without_success_state_saves_only_navigation(self):
        from main import require_calibrated, setup
        self.configure_two_step("two-step-zero")
        await self.browser.market()

        @asynccontextmanager
        async def existing_session(*args, **kwargs):
            yield self.browser

        answers = ["h2", "none", "data-id", "", "", "yes", "1", "", ""]
        with patch("main.BrowserSession", existing_session), patch("main.authenticate", AsyncMock()), \
             patch("main.pick_selector", AsyncMock(return_value=".project")), \
             patch("main.prompt", AsyncMock(side_effect=answers)):
            await setup(self.root, self.config)
        saved = json.loads((self.root / "config.json").read_text(encoding="utf-8"))
        self.assertTrue(saved["navigation_calibrated"])
        self.assertFalse(saved["calibrated"])
        self.assertEqual(saved["selectors"]["confirmed"], "")
        require_calibrated(saved, dry_run=True)
        with self.assertRaises(ValueError):
            require_calibrated(saved)
        self.assertEqual(self.store.status()["claims"], [])

