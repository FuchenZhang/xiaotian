import asyncio
import io
import json
import logging
import tempfile
import unittest
from pathlib import Path

from claimbot.core import Engine, NeedsLogin, NeedsReview, Project, SiteChanged, Store, canonical_url, flush_outbox, project_key
from claimbot.push import WxPusher, load_env


PROJECT = Project("project-1", "Computer Engineering", "https://www.siriser.com/siriser/market/project?id=1")


class FakeAdapter:
    def __init__(self, projects=None, confirmed=True, existing=False, eligible=True, failure=None):
        self.projects = [PROJECT] if projects is None else projects
        self.confirmed, self.existing, self.eligible = confirmed, existing, eligible
        self.failure = failure
        self.clicks = self.opens = self.finishes = 0

    async def list_projects(self):
        return self.projects

    async def open_project(self, project):
        self.opens += 1

    async def already_claimed(self):
        return self.existing

    async def claimable(self):
        return self.eligible

    async def click_claim(self):
        self.clicks += 1
        if self.failure:
            raise self.failure

    async def wait_confirmed(self):
        return self.confirmed

    async def finish_project(self):
        self.finishes += 1


class CoreTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "claims.sqlite3"
        self.store = Store(self.path)
        self.log = logging.getLogger("tests")

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    async def test_confirm_once_and_notify_once_across_restart(self):
        adapter = FakeAdapter()
        await Engine(self.store, adapter, self.log).cycle()
        self.assertEqual(self.store.state(PROJECT.key), "confirmed")
        self.assertEqual(len(self.store.pending()), 1)
        self.store.close()
        self.store = Store(self.path)
        await Engine(self.store, adapter, self.log).cycle()
        self.assertEqual(adapter.clicks, 1)
        self.assertEqual(len(self.store.pending()), 1)

    async def test_timeout_never_notifies_success_or_retries(self):
        adapter = FakeAdapter(confirmed=False)
        engine = Engine(self.store, adapter, self.log)
        with self.assertRaises(NeedsReview):
            await engine.cycle()
        self.assertEqual(self.store.state(PROJECT.key), "uncertain")
        self.assertEqual(self.store.pending(), [])
        with self.assertRaises(NeedsReview):
            await engine.cycle()
        self.assertEqual(adapter.clicks, 1)

    async def test_loss_of_login_after_click_is_uncertain(self):
        adapter = FakeAdapter(failure=NeedsLogin())
        with self.assertRaises(NeedsLogin):
            await Engine(self.store, adapter, self.log).cycle()
        self.assertEqual(self.store.state(PROJECT.key), "uncertain")

    async def test_cancelled_click_is_uncertain(self):
        with self.assertRaises(asyncio.CancelledError):
            await Engine(self.store, FakeAdapter(failure=asyncio.CancelledError()), self.log).cycle()
        self.assertEqual(self.store.state(PROJECT.key), "uncertain")

    async def test_disabled_project_is_rechecked_next_cycle(self):
        adapter = FakeAdapter(eligible=False)
        engine = Engine(self.store, adapter, self.log)
        await engine.cycle()
        self.assertIsNone(self.store.state(PROJECT.key))
        adapter.eligible = True
        await engine.cycle()
        self.assertEqual(adapter.clicks, 1)

    async def test_dry_run_does_not_claim_or_write(self):
        adapter = FakeAdapter()
        await Engine(self.store, adapter, self.log).cycle(dry_run=True)
        self.assertEqual(adapter.clicks, 0)
        self.assertIsNone(self.store.state(PROJECT.key))
        self.assertEqual(self.store.pending(), [])

    async def test_existing_claim_skipped_without_success_push(self):
        adapter = FakeAdapter(existing=True)
        await Engine(self.store, adapter, self.log).cycle()
        self.assertEqual(adapter.clicks, 0)
        self.assertEqual(self.store.state(PROJECT.key), "existing")
        self.assertEqual(self.store.pending(), [])

    async def test_duplicate_identity_stops_before_any_click(self):
        adapter = FakeAdapter(projects=[PROJECT, PROJECT])
        with self.assertRaises(SiteChanged):
            await Engine(self.store, adapter, self.log).cycle()
        self.assertEqual(adapter.opens, 0)

    async def test_all_projects_claimed_sequentially(self):
        projects = [Project(str(i), f"Project {i}") for i in range(5)]
        adapter = FakeAdapter(projects=projects)
        await Engine(self.store, adapter, self.log).cycle()
        self.assertEqual(adapter.clicks, 5)
        self.assertEqual(adapter.finishes, 5)
        self.assertEqual(len(self.store.pending()), 5)

    async def test_notification_failure_does_not_reset_claim(self):
        self.store.confirm(PROJECT)

        class Broken:
            configured = True
            def send(self, *args):
                raise RuntimeError("network down")

        await flush_outbox(self.store, Broken(), self.log)
        self.assertEqual(self.store.state(PROJECT.key), "confirmed")
        future = self.store.pending(now=10**12)
        self.assertEqual(future[0]["tries"], 1)
        self.assertEqual(self.store.pending(), [])

    def test_recover_and_explicit_resolution(self):
        self.store.set_state(PROJECT, "attempting")
        self.store.recover()
        self.assertEqual(self.store.state(PROJECT.key), "uncertain")
        self.store.resolve(PROJECT.key, "claimed")
        self.assertEqual(self.store.state(PROJECT.key), "confirmed")
        self.assertEqual(len(self.store.pending()), 1)

    def test_not_claimed_resolution_allows_retry(self):
        self.store.set_state(PROJECT, "uncertain")
        self.store.resolve(PROJECT.key, "not-claimed")
        self.assertIsNone(self.store.state(PROJECT.key))

    def test_url_canonicalization_and_foreign_links(self):
        a = canonical_url("https://www.siriser.com/a?b=2&a=1#x")
        self.assertEqual(a, "https://www.siriser.com/a?a=1&b=2")
        for url in ["http://www.siriser.com/a", "https://evil.test/a", "https://www.siriser.com.evil.test/a", "https://user@www.siriser.com/a"]:
            with self.assertRaises(SiteChanged):
                canonical_url(url)
        self.assertEqual(project_key(a), project_key(a))


class PushTests(unittest.TestCase):
    def transport(self, result, captured):
        def open_(request, timeout):
            captured.append((request.full_url, json.loads(request.data), timeout))
            return io.BytesIO(json.dumps(result).encode())
        return open_

    def test_spt_uses_post_body_without_credentials_in_url(self):
        captured = []
        push = WxPusher({"WXPUSHER_SPT": "SPT_test"}, self.transport({"code": 1000}, captured))
        push.send("项目已领取", "已经领取：测试项目")
        self.assertEqual(captured[0][0], "https://wxpusher.zjiecode.com/api/send/message/simple-push")
        self.assertEqual(captured[0][1]["spt"], "SPT_test")
        self.assertEqual(captured[0][1]["contentType"], 1)

    def test_standard_success_validates_all_recipients(self):
        captured = []
        push = WxPusher({"WXPUSHER_MODE": "standard", "WXPUSHER_APP_TOKEN": "AT_test", "WXPUSHER_UIDS": "UID_a,UID_b"},
            self.transport({"code": 1000, "data": [{"uid": "UID_a", "code": 1000}, {"uid": "UID_b", "code": 1000}]}, captured))
        push.send("ok", "body")
        self.assertEqual(captured[0][1]["uids"], ["UID_a", "UID_b"])

    def test_partial_recipient_failure_is_not_success(self):
        push = WxPusher({"WXPUSHER_MODE": "standard", "WXPUSHER_APP_TOKEN": "AT_test", "WXPUSHER_UIDS": "UID_a,UID_b"},
            self.transport({"code": 1000, "data": [{"uid": "UID_a", "code": 1000}, {"uid": "UID_b", "code": 1001}]}, []))
        with self.assertRaises(RuntimeError):
            push.send("ok", "body")

    def test_business_error_is_not_success(self):
        push = WxPusher({"WXPUSHER_SPT": "SPT_test"}, self.transport({"code": 1001}, []))
        with self.assertRaises(RuntimeError):
            push.send("ok", "body")

    def test_no_credentials_is_disabled(self):
        self.assertFalse(WxPusher({}).configured)

    def test_env_file_does_not_execute_shell_content(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / ".env"
            path.write_text("WXPUSHER_SPT=SPT_$(whoami)\n", encoding="utf-8")
            self.assertEqual(load_env(path).get("WXPUSHER_SPT"), "SPT_$(whoami)")


if __name__ == "__main__":
    unittest.main()

