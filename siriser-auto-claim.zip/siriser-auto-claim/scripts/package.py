"""Build a source-only Linux deployment archive, excluding all private state."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT.parent / "siriser-auto-claim.zip"
SOURCES = [ROOT / name for name in (
    "main.py", "README.md", "requirements.txt", "config.example.json", ".env.example", ".gitignore")]
for folder, pattern in (("claimbot", "*.py"), ("tests", "*.py"), ("scripts", "*.sh"),
                        ("scripts", "*.service"), ("scripts", "package.py")):
    SOURCES.extend(sorted((ROOT / folder).glob(pattern)))

with ZipFile(OUTPUT, "w", ZIP_DEFLATED) as archive:
    for source in SOURCES:
        relative = source.relative_to(ROOT)
        # Text sources use LF in the Linux archive even when checked out on Windows.
        data = source.read_bytes().replace(b"\r\n", b"\n")
        archive.writestr("siriser-auto-claim/" + relative.as_posix(), data)
with ZipFile(OUTPUT) as archive:
    if archive.testzip() is not None:
        raise RuntimeError("Archive verification failed")
    print(f"Created {OUTPUT} ({len(archive.namelist())} source files; {OUTPUT.stat().st_size} bytes)")
