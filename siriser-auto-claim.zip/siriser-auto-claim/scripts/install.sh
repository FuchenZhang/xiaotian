#!/usr/bin/env bash
set -euo pipefail
umask 077
APP=/opt/siriser-auto-claim
if [[ ${EUID} -ne 0 ]]; then
  printf 'Run as root: sudo bash scripts/install.sh\n' >&2
  exit 1
fi
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
if [[ "$HERE" != "$APP" ]]; then
  printf 'Copy the complete project to %s first.\n' "$APP" >&2
  exit 1
fi
source /etc/os-release
if [[ "$ID" != ubuntu || "$VERSION_ID" != 22.04 ]]; then
  printf 'This installer targets Ubuntu 22.04; detected %s %s.\n' "$ID" "$VERSION_ID" >&2
  exit 1
fi
apt-get update
apt-get install -y sudo python3 python3-venv python3-pip xvfb x11vnc novnc websockify \
  xauth x11-utils openssl fonts-wqy-zenhei
if ! id siriser >/dev/null 2>&1; then
  useradd --system --create-home --shell /usr/sbin/nologin siriser
fi
install -d -m 700 -o siriser -g siriser "$APP/data" "$APP/logs" "$APP/.browsers"
if [[ ! -d "$APP/.venv" ]]; then
  python3 -m venv "$APP/.venv"
fi
chown -R siriser:siriser "$APP/.venv" "$APP/.browsers"
chmod 755 "$APP"
chown siriser:siriser "$APP"
chmod 755 "$APP/scripts"
chmod 644 "$APP/scripts"/*.sh "$APP/scripts"/*.service
chmod 644 "$APP"/*.py "$APP/requirements.txt" "$APP/config.example.json"
chmod -R a+rX "$APP/claimbot"
sudo -u siriser -H "$APP/.venv/bin/python" -m pip install -r "$APP/requirements.txt"
"$APP/.venv/bin/python" -m playwright install-deps chromium
sudo -u siriser -H env PLAYWRIGHT_BROWSERS_PATH="$APP/.browsers" \
  "$APP/.venv/bin/python" -m playwright install chromium
if [[ ! -f "$APP/config.json" ]]; then
  install -m 600 -o siriser -g siriser "$APP/config.example.json" "$APP/config.json"
fi
if [[ ! -f "$APP/.env" ]]; then
  install -m 600 -o siriser -g siriser "$APP/.env.example" "$APP/.env"
fi
install -m 644 "$APP/scripts/siriser-claim.service" /etc/systemd/system/siriser-claim.service
systemctl daemon-reload
printf '\nInstalled. Service is NOT started yet. Fill .env, then run setup and dry-run.\n'

