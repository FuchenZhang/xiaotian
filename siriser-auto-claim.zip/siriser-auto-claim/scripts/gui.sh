#!/usr/bin/env bash
set -euo pipefail
umask 077
APP=/opt/siriser-auto-claim
MODE=${1:-login}
if [[ "$MODE" != login && "$MODE" != setup && "$MODE" != inspect ]]; then
  printf 'Usage: gui.sh login|setup|inspect\n' >&2
  exit 1
fi
if [[ $(id -un) != siriser ]]; then
  printf 'Run: sudo -u siriser -H bash scripts/gui.sh %s\n' "$MODE" >&2
  exit 1
fi
if systemctl is-active --quiet siriser-claim.service; then
  printf 'Stop the worker before using GUI: sudo systemctl stop siriser-claim\n' >&2
  exit 1
fi
for port in 5900 6080; do
  if ss -H -ltn "sport = :$port" | grep -q .; then
    printf 'Port %s is occupied; refusing to terminate other processes.\n' "$port" >&2
    exit 1
  fi
done
temp=$(mktemp -d)
pids=()
cleanup() {
  for pid in "${pids[@]}"; do kill "$pid" 2>/dev/null || true; done
  for pid in "${pids[@]}"; do wait "$pid" 2>/dev/null || true; done
  rm -f -- "$temp/Xauthority" "$temp/vnc.pass" "$temp/xvfb.log" "$temp/vnc.log" "$temp/web.log"
  rmdir -- "$temp" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT TERM
display=''
for number in $(seq 91 119); do
  if [[ ! -e "/tmp/.X${number}-lock" && ! -e "/tmp/.X11-unix/X${number}" ]]; then
    display=$number
    break
  fi
done
if [[ -z "$display" ]]; then printf 'No free display found.\n' >&2; exit 1; fi
export DISPLAY=":$display"
export XAUTHORITY="$temp/Xauthority"
touch "$XAUTHORITY"
cookie=$(openssl rand -hex 16)
xauth -f "$XAUTHORITY" add "$DISPLAY" . "$cookie"
Xvfb "$DISPLAY" -screen 0 1440x1000x24 -nolisten tcp -auth "$XAUTHORITY" >"$temp/xvfb.log" 2>&1 &
pids+=("$!")
ready=0
for _ in $(seq 1 40); do
  if xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then ready=1; break; fi
  sleep 0.25
done
if [[ "$ready" != 1 ]]; then printf 'Xvfb failed to start.\n' >&2; exit 1; fi
password=$(openssl rand -hex 4)
x11vnc -storepasswd "$password" "$temp/vnc.pass" >/dev/null 2>&1
x11vnc -display "$DISPLAY" -auth "$XAUTHORITY" -rfbauth "$temp/vnc.pass" \
  -localhost -rfbport 5900 -forever -shared >"$temp/vnc.log" 2>&1 &
pids+=("$!")
websockify --web /usr/share/novnc 127.0.0.1:6080 127.0.0.1:5900 >"$temp/web.log" 2>&1 &
pids+=("$!")
sleep 1
for pid in "${pids[@]}"; do
  if ! kill -0 "$pid" 2>/dev/null; then printf 'GUI helper failed.\n' >&2; exit 1; fi
done
printf '\nSSH tunnel from your computer:\n  ssh -N -L 6080:127.0.0.1:6080 YOUR_SSH_USER@YOUR_SERVER\n'
printf 'Browser: http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale\n'
printf 'Temporary VNC password: %s\n\n' "$password"
cd "$APP"
export PLAYWRIGHT_BROWSERS_PATH="$APP/.browsers"
"$APP/.venv/bin/python" main.py "$MODE"

