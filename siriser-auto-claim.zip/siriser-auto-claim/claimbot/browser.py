import asyncio
import json
import sys
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit

from .core import NeedsLogin, NeedsReview, Project, RateLimited, SiteChanged, atomic_json, canonical_url, project_key


def safe_link(base, href):
    if not href or href.startswith(("#", "javascript:")):
        return ""
    result = canonical_url(urljoin(base, href))
    if urlsplit(result).path.endswith("/rule"):
        return ""
    return result


class BrowserSession:
    def __init__(self, root, config, headed=False):
        self.root, self.config, self.headed = Path(root), config, headed
        self.context = self.page = self.playwright = None
        self.detail = None
        self.http_problem = None

    async def __aenter__(self):
        from playwright.async_api import async_playwright
        self.playwright = await async_playwright().start()
        try:
            self.context = await self.playwright.chromium.launch_persistent_context(
                str(self.root / "data" / "browser"), headless=not self.headed,
                chromium_sandbox=sys.platform.startswith("linux"),
                viewport={"width": 1440, "height": 900}, locale="zh-CN",
                accept_downloads=False)
            self.context.set_default_timeout(8000)
            self.context.set_default_navigation_timeout(self.config["navigation_timeout_ms"])
            saved_cookies = self.root / "data" / "auth-cookies.json"
            if saved_cookies.exists():
                cookies = json.loads(saved_cookies.read_text(encoding="utf-8"))
                cookies = [c for c in cookies if c.get("expires", -1) == -1 or c.get("expires", 0) > time.time()]
                await self.context.add_cookies(cookies)
            saved_session = self.root / "data" / "session-storage.json"
            if saved_session.exists() and not self.headed:
                entries = json.loads(saved_session.read_text(encoding="utf-8"))
                await self.context.add_init_script(script="""(() => {
                    if (location.origin !== 'https://www.siriser.com') return;
                    const values = %s;
                    for (const [key,value] of Object.entries(values)) {
                        if (sessionStorage.getItem(key) === null) sessionStorage.setItem(key,value);
                    }
                })();""" % json.dumps(entries, ensure_ascii=True))
            self.page = self.context.pages[0] if self.context.pages else await self.context.new_page()
            self.context.on("response", self._response)
            self.context.on("dialog", lambda dialog: asyncio.create_task(dialog.dismiss()))
            return self
        except BaseException:
            if self.context:
                await self.context.close()
            await self.playwright.stop()
            raise

    async def __aexit__(self, *args):
        try:
            if self.context:
                await self.context.close()
        finally:
            if self.playwright:
                await self.playwright.stop()

    async def save_auth(self, page=None):
        page = page or self.page
        await self.check(page)
        atomic_json(self.root / "data" / "auth-cookies.json", await self.context.cookies())
        entries = await page.evaluate("Object.fromEntries(Object.entries(sessionStorage))")
        atomic_json(self.root / "data" / "session-storage.json", entries)

    def _response(self, response):
        if urlsplit(response.url).hostname == "www.siriser.com" and response.status in (401, 403, 429):
            self.http_problem = response.status

    @property
    def s(self):
        return self.config["selectors"]

    async def visible(self, page, selector):
        if not selector:
            return False
        locator = page.locator(selector)
        return await locator.count() > 0 and await locator.first.is_visible()

    async def check(self, page):
        if urlsplit(page.url).hostname != "www.siriser.com":
            raise NeedsLogin("Browser is at the authentication page")
        if self.http_problem == 401:
            raise NeedsLogin("Session was rejected")
        if self.http_problem == 429:
            raise RateLimited("Website returned HTTP 429")
        if self.http_problem == 403:
            raise NeedsReview("Website denied access; manual verification required")
        if await self.visible(page, self.s.get("challenge", "")):
            raise NeedsReview("A verification challenge requires manual interaction")

    async def market(self):
        self.http_problem = None
        await self.page.goto(self.config["market_url"], wait_until="domcontentloaded")
        await self.check(self.page)
        try:
            await self.page.locator(self.s["market_ready"]).first.wait_for(
                state="visible", timeout=self.config["navigation_timeout_ms"])
        except Exception:
            await self.check(self.page)
            raise SiteChanged("The calibrated project-center marker was not found") from None
        await self.page.wait_for_timeout(self.config["page_delay_seconds"] * 1000)
        await self.check(self.page)

    async def card_pairs(self, page_number):
        cards = self.page.locator(self.s["card"])
        count = await cards.count()
        if count > 1000:
            raise SiteChanged("Card selector matches too many elements")
        result = []
        for i in range(count):
            card = cards.nth(i)
            if not await card.is_visible():
                continue
            title_locator = card.locator(self.s["title"]) if self.s["title"] else card
            if await title_locator.count() != 1:
                raise SiteChanged("Project title selector is ambiguous")
            title = (await title_locator.inner_text()).strip().split("\n")[0][:300]
            if not title:
                raise SiteChanged("A project has an empty title")
            urls = set()
            if self.s["detail_link"]:
                links = card.locator(self.s["detail_link"])
                for j in range(await links.count()):
                    url = safe_link(self.page.url, await links.nth(j).get_attribute("href"))
                    if url:
                        urls.add(url)
            own_href = await card.get_attribute("href")
            if own_href:
                own_url = safe_link(self.page.url, own_href)
                if own_url:
                    urls.add(own_url)
            ident = await card.get_attribute(self.s["id_attribute"]) if self.s["id_attribute"] else None
            if ident:
                identity = "id:" + self.s["id_attribute"] + ":" + ident
                url = next(iter(urls)) if len(urls) == 1 else ""
            elif len(urls) == 1:
                url = next(iter(urls))
                if url == canonical_url(self.config["market_url"]):
                    raise SiteChanged("Project link points back to the project center")
                identity = "url:" + url
            else:
                raise SiteChanged("Project needs a unique detail URL or a calibrated ID attribute")
            result.append((Project(project_key(identity), title, url, identity, page_number), card))
        keys = [p.key for p, _ in result]
        if len(keys) != len(set(keys)):
            raise SiteChanged("Card selector produced duplicate project identities")
        return result

    async def next_page(self):
        if not self.s.get("next_page"):
            raise SiteChanged("Pagination selector has not been calibrated")
        button = self.page.locator(self.s["next_page"])
        if await button.count() != 1:
            raise SiteChanged("Next-page selector is ambiguous or missing")
        if not await button.is_visible() or not await button.is_enabled():
            return False
        if await button.get_attribute("aria-disabled") == "true":
            return False
        if await button.evaluate("e => !!e.closest('[disabled], [aria-disabled=\"true\"]')"):
            return False
        before = [p.key for p, _ in await self.card_pairs(0)]
        await button.click()
        deadline = time.monotonic() + self.config["navigation_timeout_ms"] / 1000
        while time.monotonic() < deadline:
            await self.check(self.page)
            current = [p.key for p, _ in await self.card_pairs(0)]
            if current and current != before:
                return True
            await self.page.wait_for_timeout(250)
        raise SiteChanged("Pagination did not change the project list")

    async def expand_scroll(self):
        stable = 0
        before = set()
        for _ in range(self.config["max_scrolls"]):
            keys = {p.key for p, _ in await self.card_pairs(0)}
            if not before.issubset(keys):
                raise SiteChanged("Virtualized list needs a site-specific adapter")
            stable = stable + 1 if keys == before else 0
            if stable >= 3:
                return
            before = keys
            await self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await self.page.wait_for_timeout(self.config["page_delay_seconds"] * 1000)
            await self.check(self.page)
        raise SiteChanged("Scroll limit reached; refusing a partial scan")

    async def list_projects(self):
        await self.market()
        if self.config["list_mode"] == "scroll":
            await self.expand_scroll()
        result = {}
        fingerprints = set()
        for index in range(self.config["max_pages"]):
            pairs = await self.card_pairs(index)
            fingerprint = tuple(p.key for p, _ in pairs)
            if fingerprint and fingerprint in fingerprints:
                raise SiteChanged("Pagination repeats an earlier page")
            fingerprints.add(fingerprint)
            for p, _ in pairs:
                result.setdefault(p.key, p)
            if self.config["list_mode"] != "pagination" or not await self.next_page():
                return list(result.values())
        raise SiteChanged("Page limit reached; refusing a partial scan")

    async def open_project(self, project):
        if project.url:
            self.detail = self.page
            await self.page.goto(project.url, wait_until="domcontentloaded")
        else:
            await self.market()
            if self.config["list_mode"] == "scroll":
                await self.expand_scroll()
            for _ in range(project.list_page):
                if not await self.next_page():
                    raise SiteChanged("Project list changed before opening the project")
            matches = [card for p, card in await self.card_pairs(project.list_page) if p.key == project.key]
            if len(matches) != 1:
                raise SiteChanged("Project card is no longer unique")
            old_pages = list(self.context.pages)
            entry = self.s.get("entry", "")
            control = matches[0].locator(entry) if entry else matches[0]
            if await control.count() != 1:
                raise SiteChanged("The project-entry control is missing or ambiguous")
            await control.click()
            await self.page.wait_for_timeout(self.config["page_delay_seconds"] * 1000)
            new_pages = [p for p in self.context.pages if p not in old_pages]
            if len(new_pages) > 1:
                raise SiteChanged("Opening the card produced multiple tabs")
            self.detail = new_pages[0] if new_pages else self.page
            await self.detail.wait_for_load_state("domcontentloaded")
        await self.detail.wait_for_timeout(self.config["page_delay_seconds"] * 1000)
        await self.check(self.detail)
        ready = self.s.get("detail_ready", "")
        if ready:
            deadline = time.monotonic() + self.config["navigation_timeout_ms"] / 1000
            while not (await self.visible(self.detail, ready) or
                       await self.visible(self.detail, self.s.get("confirmed", ""))):
                await self.check(self.detail)
                if time.monotonic() >= deadline:
                    raise SiteChanged("The second-stage claim page did not become ready")
                await self.detail.wait_for_timeout(200)
            await self.check(self.detail)
        if canonical_url(self.detail.url) == canonical_url(self.config["market_url"]):
            raise SiteChanged("The entry control did not leave the project center")

    async def already_claimed(self):
        await self.check(self.detail)
        return await self.visible(self.detail, self.s["confirmed"])

    async def claimable(self):
        await self.check(self.detail)
        button = self.detail.locator(self.s["claim"])
        if await button.count() == 0:
            return False
        if await button.count() != 1:
            raise SiteChanged("Claim selector matches more than one control")
        if not await button.is_visible() or not await button.is_enabled():
            return False
        if await button.get_attribute("aria-disabled") == "true":
            return False
        if await button.evaluate("e => !!e.closest('[disabled], [aria-disabled=\"true\"]')"):
            return False
        success = self.s.get("success", "")
        if await self.visible(self.detail, success):
            try:
                await self.detail.locator(success).first.wait_for(state="hidden", timeout=5000)
            except Exception:
                raise SiteChanged("A pre-existing success marker cannot confirm a new claim") from None
        return True

    async def click_claim(self):
        await self.check(self.detail)
        await self.detail.locator(self.s["claim"]).click()
        confirmation = self.s.get("confirm_dialog")
        if confirmation:
            control = self.detail.locator(confirmation)
            try:
                await control.wait_for(state="visible", timeout=3000)
            except Exception:
                return
            if await control.count() != 1:
                raise NeedsReview("Confirmation dialog is ambiguous")
            await control.click()

    async def wait_confirmed(self):
        deadline = time.monotonic() + self.config["confirmation_timeout_ms"] / 1000
        while time.monotonic() < deadline:
            await self.check(self.detail)
            if await self.visible(self.detail, self.s["confirmed"]) or await self.visible(self.detail, self.s.get("success", "")):
                return True
            await self.detail.wait_for_timeout(200)
        return False

    async def finish_project(self):
        if self.detail and self.detail != self.page and not self.detail.is_closed():
            await self.detail.close()
        self.detail = None

    async def diagnostics(self):
        await self.check(self.page)
        controls = await self.page.locator("a,button,[role=button]").evaluate_all("""nodes => nodes
          .filter(e => e.getBoundingClientRect().width && e.getBoundingClientRect().height)
          .slice(0,300).map(e => ({tag:e.tagName,text:(e.innerText||'').slice(0,200),
            href:e.tagName==='A'?e.getAttribute('href'):null,id:e.id,className:e.className}))""")
        return {"url": self.page.url, "controls": controls}


PICKER = r"""() => new Promise(resolve => {
  const original = document.documentElement.style.cursor;
  document.documentElement.style.cursor = 'crosshair';
  function css(el) {
    if (el.id) return '#' + CSS.escape(el.id);
    const parts=[];
    while(el && el.nodeType===1 && el.tagName!=='HTML') {
      let part=el.tagName.toLowerCase();
      const classes=Array.from(el.classList).filter(c=>c.length<100);
      if(classes.length) part+='.'+classes.map(CSS.escape).join('.');
      const same=el.parentElement ? Array.from(el.parentElement.children).filter(x=>x.tagName===el.tagName):[];
      if(same.length>1) part+=':nth-of-type('+(same.indexOf(el)+1)+')';
      parts.unshift(part); el=el.parentElement;
    }
    return parts.join(' > ');
  }
  function handler(event) {
    event.preventDefault(); event.stopImmediatePropagation();
    document.removeEventListener('click', handler, true);
    document.documentElement.style.cursor=original;
    const ancestors=[];
    for(let e=event.target, n=0; e && n<6; e=e.parentElement,n++) {
      let generic=e.tagName.toLowerCase();
      if(e.classList.length) generic+='.'+Array.from(e.classList).map(CSS.escape).join('.');
      ancestors.push({selector:css(e),generic,text:(e.innerText||'').slice(0,150),
        attributes:Array.from(e.attributes).filter(a=>/^data-.*id$/.test(a.name)).map(a=>a.name)});
    }
    resolve({text:(event.target.innerText||'').trim(),ancestors});
  }
  document.addEventListener('click', handler, true);
})"""


async def prompt(text):
    return (await asyncio.to_thread(input, text)).strip()


async def pick_selector(page, description, repeated=False):
    print(description, flush=True)
    picked = await page.evaluate(PICKER)
    choices = []
    for item in picked["ancestors"]:
        selector = item["generic"] if repeated else item["selector"]
        if selector in {c[0] for c in choices}:
            continue
        locator = page.locator(selector)
        count = await locator.count()
        texts = [((await locator.nth(i).inner_text()).strip().replace("\n", " ")[:80]) for i in range(min(count, 3))]
        choices.append((selector, item))
        print(f"{len(choices)}. {selector}\n   匹配 {count} 个：{texts}", flush=True)
        if item.get("attributes"):
            print("   可作为项目ID的属性：" + ", ".join(item["attributes"]), flush=True)
    if not repeated and picked["text"]:
        exact_text = "text=" + json.dumps(picked["text"], ensure_ascii=False)
        if await page.locator(exact_text).count() == 1:
            choices.append((exact_text, {}))
            print(f"{len(choices)}. {exact_text}")
    while True:
        value = await prompt("选择编号（可直接输入 CSS/Playwright 选择器）：")
        selector = choices[int(value) - 1][0] if value.isdigit() and 1 <= int(value) <= len(choices) else value
        try:
            count = await page.locator(selector).count()
            if count and (repeated or count == 1):
                return selector
        except Exception:
            pass
        print("没有匹配，或匹配了多个控件，请重新选择。")

