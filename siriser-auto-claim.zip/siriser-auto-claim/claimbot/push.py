import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path


def load_env(path):
    result = dict(os.environ)
    if not Path(path).exists():
        return result
    for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, value = line.partition("=")
        if not sep or not re.fullmatch(r"[A-Z_][A-Z0-9_]*", key):
            raise ValueError("Invalid .env line")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        result.setdefault(key, value)
    return result


class WxPusher:
    def __init__(self, env, opener=None):
        self.mode = env.get("WXPUSHER_MODE", "spt")
        self.spt = env.get("WXPUSHER_SPT", "").strip()
        self.app_token = env.get("WXPUSHER_APP_TOKEN", "").strip()
        self.uids = [v.strip() for v in env.get("WXPUSHER_UIDS", "").split(",") if v.strip()]
        self.opener = opener or urllib.request.urlopen
        if self.mode not in ("spt", "standard"):
            raise ValueError("WXPUSHER_MODE must be spt or standard")

    @property
    def configured(self):
        if self.mode == "spt":
            return self.spt.startswith("SPT_") and len(self.spt) > 4
        return self.app_token.startswith("AT_") and bool(self.uids) and all(u.startswith("UID_") for u in self.uids)

    def send(self, title, content, url=""):
        if not self.configured:
            raise ValueError("WxPusher credentials are not configured")
        body = {"summary": title[:100], "content": content[:10000], "contentType": 1}
        if url:
            body["url"] = url
        if self.mode == "spt":
            endpoint = "https://wxpusher.zjiecode.com/api/send/message/simple-push"
            body["spt"] = self.spt
        else:
            endpoint = "https://wxpusher.zjiecode.com/api/send/message"
            body.update(appToken=self.app_token, uids=self.uids)
        request = urllib.request.Request(endpoint,
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST")
        try:
            with self.opener(request, timeout=12) as response:
                result = json.loads(response.read(262144))
        except (urllib.error.URLError, ValueError, OSError):
            raise RuntimeError("WxPusher transport failed") from None
        if result.get("code") != 1000:
            raise RuntimeError("WxPusher did not accept this notification")
        if self.mode == "standard":
            records = result.get("data")
            if not isinstance(records, list) or not records:
                raise RuntimeError("WxPusher returned no recipient result")
            successful = {r.get("uid") for r in records if r.get("code") == 1000}
            if not set(self.uids).issubset(successful):
                raise RuntimeError("WxPusher rejected one or more recipients")
        return result

