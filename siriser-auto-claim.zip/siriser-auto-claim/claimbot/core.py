import asyncio
import hashlib
import json
import os
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


class NeedsLogin(Exception):
    pass


class NeedsReview(Exception):
    pass


class SiteChanged(Exception):
    pass


class RateLimited(Exception):
    pass


def canonical_url(url):
    p = urlsplit(url)
    if p.scheme != "https" or p.hostname != "www.siriser.com" or p.port not in (None, 443):
        raise SiteChanged("Project link is not an approved Siriser HTTPS URL")
    if p.username or p.password:
        raise SiteChanged("URL contains credentials")
    return urlunsplit(("https", "www.siriser.com", p.path, urlencode(sorted(parse_qsl(p.query))), ""))


def project_key(identity):
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(temp, 0o600)
    os.replace(temp, path)


@dataclass(frozen=True)
class Project:
    key: str
    title: str
    url: str = ""
    identity: str = ""
    list_page: int = 0


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(self.path)
        os.chmod(self.path, 0o600)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS projects (
                key TEXT PRIMARY KEY, title TEXT, url TEXT,
                state TEXT NOT NULL, updated REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS outbox (
                id TEXT PRIMARY KEY, title TEXT NOT NULL, content TEXT NOT NULL,
                url TEXT NOT NULL, tries INTEGER NOT NULL DEFAULT 0,
                next_try REAL NOT NULL DEFAULT 0, sent INTEGER NOT NULL DEFAULT 0);
        """)

    def state(self, key):
        row = self.db.execute("SELECT state FROM projects WHERE key=?", (key,)).fetchone()
        return row[0] if row else None

    def set_state(self, project, state):
        with self.db:
            self.db.execute("""INSERT INTO projects VALUES (?,?,?,?,?)
                ON CONFLICT(key) DO UPDATE SET title=excluded.title, url=excluded.url,
                state=excluded.state, updated=excluded.updated""",
                (project.key, project.title, project.url, state, time.time()))

    def confirm(self, project):
        # The claim record and its notification become durable in one transaction.
        with self.db:
            self.db.execute("""INSERT INTO projects VALUES (?,?,?,?,?)
                ON CONFLICT(key) DO UPDATE SET state=excluded.state, updated=excluded.updated""",
                (project.key, project.title, project.url, "confirmed", time.time()))
            self.db.execute("INSERT OR IGNORE INTO outbox(id,title,content,url) VALUES(?,?,?,?)",
                ("claim:" + project.key, "项目已领取", f"已经领取：{project.title}\n项目编号：{project.key}", project.url))

    def unresolved(self):
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM projects WHERE state IN ('attempting','uncertain') ORDER BY updated")]

    def recover(self):
        with self.db:
            self.db.execute("UPDATE projects SET state='uncertain' WHERE state='attempting'")
        return self.unresolved()

    def resolve(self, key, result):
        row = self.db.execute("SELECT * FROM projects WHERE key=?", (key,)).fetchone()
        if not row or row["state"] not in ("attempting", "uncertain"):
            raise ValueError("No unresolved claim with this key")
        if result == "claimed":
            self.confirm(Project(row["key"], row["title"], row["url"]))
        elif result == "not-claimed":
            with self.db:
                self.db.execute("DELETE FROM projects WHERE key=?", (key,))
        else:
            raise ValueError("Unknown resolution")

    def enqueue(self, key, title, content, url=""):
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO outbox(id,title,content,url) VALUES(?,?,?,?)",
                            (key, title, content, url))

    def pending(self, now=None, limit=10):
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM outbox WHERE sent=0 AND next_try<=? ORDER BY rowid LIMIT ?",
            (time.time() if now is None else now, limit))]

    def sent(self, key):
        with self.db:
            self.db.execute("UPDATE outbox SET sent=1 WHERE id=?", (key,))

    def failed(self, key):
        with self.db:
            row = self.db.execute("SELECT tries FROM outbox WHERE id=?", (key,)).fetchone()
            tries = row[0] + 1
            delay = min(3600, 30 * 2 ** min(tries - 1, 7))
            self.db.execute("UPDATE outbox SET tries=?, next_try=? WHERE id=?",
                            (tries, time.time() + delay, key))

    def status(self):
        return {
            "claims": [dict(r) for r in self.db.execute("SELECT * FROM projects ORDER BY updated DESC LIMIT 30")],
            "pending_notifications": self.db.execute("SELECT count(*) FROM outbox WHERE sent=0").fetchone()[0],
        }

    def close(self):
        self.db.close()


class Engine:
    def __init__(self, store, adapter, logger):
        self.store, self.adapter, self.logger = store, adapter, logger

    async def cycle(self, dry_run=False):
        if self.store.unresolved():
            raise NeedsReview("A previous claim has an unknown result; reconcile it before retrying")
        projects = await self.adapter.list_projects()
        keys = [p.key for p in projects]
        if len(keys) != len(set(keys)):
            raise SiteChanged("Duplicate project identities; refusing ambiguous claims")
        self.logger.info("SCAN projects=%d dry_run=%s", len(projects), dry_run)
        for project in projects:
            if self.store.state(project.key) in ("confirmed", "existing"):
                continue
            attempted = False
            try:
                await self.adapter.open_project(project)
                if await self.adapter.already_claimed():
                    if not dry_run:
                        self.store.set_state(project, "existing")
                    continue
                if not await self.adapter.claimable():
                    continue
                self.logger.info("ELIGIBLE key=%s title=%s", project.key, project.title)
                if dry_run:
                    continue
                # Persist intent before dispatching a click; a crash cannot cause a blind retry.
                self.store.set_state(project, "attempting")
                attempted = True
                await self.adapter.click_claim()
                if not await self.adapter.wait_confirmed():
                    raise NeedsReview("Claim confirmation was not observed")
                self.store.confirm(project)
                self.logger.info("CLAIM_CONFIRMED key=%s title=%s", project.key, project.title)
            except BaseException:
                if attempted and self.store.state(project.key) != "confirmed":
                    self.store.set_state(project, "uncertain")
                raise
            finally:
                await self.adapter.finish_project()
        return len(projects)


async def flush_outbox(store, notifier, logger, stop=None):
    if not notifier.configured:
        return
    for message in store.pending():
        if stop and stop.is_set():
            return
        try:
            await asyncio.to_thread(notifier.send, message["title"], message["content"], message["url"])
            store.sent(message["id"])
            logger.info("PUSH_ACCEPTED id=%s", message["id"])
        except Exception:
            store.failed(message["id"])
            logger.warning("PUSH_FAILED id=%s; queued for retry", message["id"])
        await asyncio.sleep(0.6)

