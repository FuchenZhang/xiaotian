"""Single-account project claiming worker."""

