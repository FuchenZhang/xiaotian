# 晓天睿士自动领取脚本

面向 Ubuntu 22.04（截图所示 2 核 / 2 GiB 服务器）。每 60 秒检查一次，顺序尝试当前账号所有可领取项目，不设置学科关键词过滤。仅操作项目领取，不代做考核、填写任务、签署协议或绕过短信/滑块验证。

## 当前完成范围

- Playwright 单浏览器持久登录；Cookie、localStorage、IndexedDB 和 Siriser 的 sessionStorage 状态保存在本机。服务端令牌到期仍须本人重登，不延长令牌有效期。
- 60 秒单进程轮询；一轮超过一分钟时跳过错过的周期，不并发叠加请求。
- SQLite 领取去重；点击前记录意图，确认后记录成功。中途断网、崩溃或无法确认时暂停，绝不盲目再次领取。
- WxPusher SPT / appToken+UID；成功、登录失效、限流和暂停通知。推送失败持久排队重试，不把点击本身当作成功。
- noVNC 远程短信登录和可视化选择器校准；只监听服务器 127.0.0.1，使用 SSH 隧道，不开放公网端口。
- 分页 / 无限滚动 / 单页列表适配；异常分页或虚拟列表暂停，避免误报已检查全部项目。
- 两步入口：卡片的“去领取”仅进入详情页；详情的“领取回答”才实际领取。等待详情控件加载，按钮禁用时跳过，不产生成功记录。

**重要：已根据你提供的截图区分“去领取 → 详情页领取回答”，但尚未使用你的账号完成真实页面 DOM 和领取成功状态联调，因此 `calibrated=false`。首次部署执行 `setup` 校准项目卡片和按钮；没有成功状态时可先保存只读配置。实际自动领取仍须完成真实成功标记的校准。** 不把截图里的按钮文字或总体领取统计预设成已验证的成功判定。

## 1. 上传并安装

将整个目录上传到服务器 `/opt/siriser-auto-claim`。首次安装使用 root 或有 sudo 权限的 SSH 账户；脚本本身以独立的 `siriser` 用户运行。以下命令在服务器执行：

```bash
cd /opt/siriser-auto-claim
sudo bash scripts/install.sh
```

安装程序创建 Python 虚拟环境、下载 Chromium、安装 Xvfb/noVNC 和 systemd 服务，但**不启动领取**。需要访问 Ubuntu 软件源、PyPI 和 Playwright 浏览器下载站点。不需要 Docker。

不要把原 Windows 机器的 `.venv` 或 `.browsers` 上传到 Linux。代码文件无需含任何真实密钥。

## 2. 配置 WxPusher

编辑服务器上的 `.env`（默认权限 600、属主 siriser）。推荐个人 SPT：

```dotenv
WXPUSHER_MODE=spt
WXPUSHER_SPT=SPT_你的真实令牌
```

到 [WxPusher SPT 官方入口](https://wxpusher.zjiecode.com/docs/spt.html) 按说明扫码获取 SPT。也支持标准推送：

```dotenv
WXPUSHER_MODE=standard
WXPUSHER_APP_TOKEN=AT_你的应用令牌
WXPUSHER_UIDS=UID_你的接收用户
```

标准模式需创建应用并关注应用，UID 可逗号分隔。保持未使用模式的凭证为空即可。凭证不写入日志、通知或命令行。

```bash
cd /opt/siriser-auto-claim
sudo -u siriser -H .venv/bin/python main.py test-push
```

必须在手机确认收到测试消息。接口接受推送不等于手机已实际送达；脚本检查接口返回码和标准模式每个接收人的返回结果。默认缺少推送凭证不能启动实际领取。

## 3. 短信登录并校准（首次一次）

在服务器 SSH 终端执行：

```bash
cd /opt/siriser-auto-claim
sudo systemctl stop siriser-claim
sudo -u siriser -H bash scripts/gui.sh setup
```

保持该终端打开。另一台电脑的终端建立隧道（使用你自己的 SSH 用户和服务器地址）：

```bash
ssh -N -L 6080:127.0.0.1:6080 SSH用户@服务器地址
```

电脑浏览器打开 `http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale`，输入服务器终端输出的一次性 VNC 密码。此密码只用于本次登录窗口，不是平台密码。**不要在服务器防火墙开放 5900 或 6080。**

1. 在窗口内完成手机号短信登录；滑块、验证码均由你人工完成。进入项目中心后回服务器终端按 Enter。
2. 选择器工具让你点击卡片标题；此次点击会被截获，不会领取。终端列出父级候选，选择匹配所有项目卡片、而非整页的候选；检查列出的项目名称。
3. 如果卡片有详情链接，默认 `a[href]`；如有多个链接，填写具体详情链接选择器。没有链接时须填写实际唯一项目ID属性（例如实际存在的 `data-id`），不能靠同名标题猜项目ID。卡片内入口默认 `text="去领取"`，这是导航，不是实际领取。
4. 选择列表类型；有分页选择下一页按钮。列表在内部滚动容器、虚拟化或特殊多层标签中时，需进一步适配，工具会停止而不会冒充完成全量检查。
5. 在终端选择一个项目编号，余量为 0 也能校准。工具进入它的详情，实际领取控件默认 `text="领取回答"`；可填写专属选择器，或输入 `pick` 可视化选择。禁用按钮不便点击拾取时使用文本选择器。本步骤不会领取。
6. 没有成功状态可核实，直接回车：保存 `navigation_calibrated=true`、`calibrated=false` 的只读配置，可先做下一节的只读试跑，不要求上传成功截图，也不强迫手动领取。实际自动领取仍禁用。能核实时输入 `yes`，打开本人已领取的项目/任务，或在确实需要时人工领取一次，再选择**明确表示本人实际领取成功的稳定标记**。不能选择“已领取/余量”的项目总体统计、“查看详情”或单纯的禁用按钮。
7. 如有普通二次确认，可设置其专属选择器。协议、考试、签约等按钮不要配置成领取确认按钮；遇到这些环节自行处理。

页面的字样若不是“项目中心”，先修改 `config.json` 的 `selectors.market_ready`。已领取与领取按钮必须分别对应未领取和已领取状态；不要选择全页通用外壳元素。工具将真实选择器写入 `config.json`，其他项目使用相同模板。没有链接和实际项目ID属性时，需要提供不含凭证的页面诊断进一步适配，不能仅靠截图推断 DOM 属性。

## 4. 只读试跑，然后启动

```bash
cd /opt/siriser-auto-claim
sudo -u siriser -H env PLAYWRIGHT_BROWSERS_PATH=/opt/siriser-auto-claim/.browsers \
  .venv/bin/python main.py run --once --dry-run
```

这一步只打开详情并检查领取按钮，不点击领取、不发领取通知、不写成功记录。日志出现 `ELIGIBLE` 是“可领取”，不是“已领取”。先确认检查的列表范围和项目名称正确；无项目可验证时不要认为已完成真实联调。

仅保存了只读配置时，先不要启动后台服务；等能核实真实成功状态后重新 `setup` 完成确认校准。图示“项目余量 0 / 领取回答禁用”是无余量，不是本人已领取成功；下一轮会重新检查。余量展示可能变化，点击后的真实反馈才用于确认。

```bash
sudo systemctl enable --now siriser-claim
sudo journalctl -u siriser-claim -f
```

真正确认成功后日志为 `CLAIM_CONFIRMED`，手机收到“已经领取：项目名称”。没有项目时不发每分钟空通知。领取容量耗尽或按钮禁用则跳过，下一分钟重新检查。已领取项目不会重复点击。

## 5. 登录失效 / 暂停处理

登录失效、403、429 或验证阻断时暂停并通知；服务仍在运行以重试待发送通知，不继续刷新项目页面。

```bash
sudo systemctl stop siriser-claim
cd /opt/siriser-auto-claim
sudo -u siriser -H bash scripts/gui.sh login
# 按上述 SSH 隧道流程重新短信登录，完成后：
sudo -u siriser -H .venv/bin/python main.py resume
sudo systemctl start siriser-claim
```

如果通知是“领取结果不明确”，先检查：

```bash
sudo -u siriser -H .venv/bin/python main.py status
```

按输出的项目 `key` 去平台本人核对，再执行其中一项：

```bash
.venv/bin/python main.py resolve 项目key --result claimed --checked
.venv/bin/python main.py resolve 项目key --result not-claimed --checked
```

服务器应给这两条命令加上 `sudo -u siriser -H`。第一项记录已领取并排队通知；第二项允许后续再次尝试。**不能确认时不要选择 not-claimed。** 所有未确认条目处理后再 `resume`。

页面改版时停服务重新 `setup`。需要协助适配时：

```bash
sudo -u siriser -H bash scripts/gui.sh inspect
```

检查 `data/page-inspection.json` 和 `data/project-center.png`。诊断不读取密码、短信输入值或 Cookie；仍可能含项目资料，分享前检查。不要发送 `data/browser`、`auth-cookies.json`、`session-storage.json` 或 `.env`。

## 文件与限制

- `main.py`：命令入口；`claimbot`：浏览器、去重、WxPusher 实现。
- `config.json`：页面选择器与固定 60 秒周期；`.env`：推送密钥。
- `data/claims.sqlite3`：领取状态与通知队列；`data/PAUSED.json`：暂停原因。
- `logs/worker.log`：滚动日志，单份最多 2 MiB，保留 3 份。
- SQLite 与 Cookie 文件只放自己的服务器，勿提交到 Git 或公共网盘。换另一个平台账号前停止服务并使用独立目录，不能混用领取记录和登录状态。
- 不保证“抢到所有项目”，项目可能在检查间隔内被领完，也可能需要资质、考试或额外人工协议。脚本只尝试当前账号实际显示可领取的项目。
- HTTP 超时、进程终止等情况下，推送接口可能已经接收但回包丢失，重试可能带来重复提醒；不会因此再次点击领取。
- 2 GiB 服务器只运行一个 Chromium。内存上限 1400 MiB，建议不要同时部署多个大内存程序；安装阶段本机/网络资源不足需排查后继续。

## 开发验证

```bash
python -m unittest discover -s tests -v
python -m unittest tests.test_browser -v
```

核心测试使用假的项目页面与假的推送响应。浏览器测试使用 Playwright 的请求拦截模拟页面，**不发送真实领取请求或真实推送**。它们验证实现，不替代真实账号部署联调。

依据：[Playwright 持久浏览器](https://playwright.dev/python/docs/api/class-browsertype#browser-type-launch-persistent-context)、[登录状态](https://playwright.dev/python/docs/auth)、[WxPusher 标准推送](https://wxpusher.zjiecode.com/docs/api-reference.html)、[SPT 推送](https://wxpusher.zjiecode.com/docs/spt.html)、[noVNC](https://github.com/novnc/noVNC)。
